const fs = require('fs');
const path = require('path');

const inputPath = path.join(__dirname, 'assets', 'TagLines.txt');
const outputPath = path.join(__dirname, 'generatedTaglineEffects.css');

const effects = {
  fade: `
@keyframes fade {
  0% { opacity: 0; }
  50% { opacity: 1; }
  100% { opacity: 0; }
}
.fade {
  animation: fade 4s ease-in-out infinite;
}
`,
  slide: `
@keyframes slide {
  0% { transform: translateX(-100%); opacity: 0; }
  50% { transform: translateX(0); opacity: 1; }
  100% { transform: translateX(100%); opacity: 0; }
}
.slide {
  animation: slide 4s ease-in-out infinite;
}
`,
  zoom: `
@keyframes zoom {
  0% { transform: scale(0); opacity: 0; }
  50% { transform: scale(1); opacity: 1; }
  100% { transform: scale(0); opacity: 0; }
}
.zoom {
  animation: zoom 4s ease-in-out infinite;
}
`,
  rotate: `
@keyframes rotate {
  0% { transform: rotate(0deg); opacity: 0; }
  50% { transform: rotate(360deg); opacity: 1; }
  100% { transform: rotate(0deg); opacity: 0; }
}
.rotate {
  animation: rotate 4s ease-in-out infinite;
}
`
};

fs.readFile(inputPath, 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading TagLines.txt:', err);
    return;
  }

  const taglines = data.split('\n').filter(line => line.trim() !== '');
  console.log(`Found ${taglines.length} taglines.`);

  let cssContent = '/* Generated CSS animation classes for taglines */\n\n';
  for (const effect in effects) {
    cssContent += effects[effect] + '\n';
  }

  fs.writeFile(outputPath, cssContent, 'utf8', err => {
    if (err) {
      console.error('Error writing CSS file:', err);
    } else {
      console.log(`CSS animation classes written to ${outputPath}`);
    }
  });
});
